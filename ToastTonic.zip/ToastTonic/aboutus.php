<?php
session_start();
?>

<html>

  <head>
    <title> About | ToastTonic </title>
  </head>

  <link rel="stylesheet" type = "text/css" href ="css/aboutus.css">
  <link rel="stylesheet" type = "text/css" href ="css/bootstrap.min.css">
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>

  <body>

  <!--Back to top button..................................................................................-->
    <button onclick="topFunction()" id="myBtn" title="Go to top">
      <span class="glyphicon glyphicon-chevron-up"></span>
    </button>
  <!--Javacript for back to top button....................................................................-->
    <script type="text/javascript">
      window.onscroll = function()
      {
        scrollFunction()
      };

      function scrollFunction(){
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
          document.getElementById("myBtn").style.display = "block";
        } else {
          document.getElementById("myBtn").style.display = "none";
        }
      }

      function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
      }
    </script>

    <nav class="navbar navbar-inverse navbar-fixed-top navigation-clean-search" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myNavbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">Toast & Tonic</a>
        </div>

        <div class="collapse navbar-collapse " id="myNavbar">
          <ul class="nav navbar-nav">
            <li><a href="index.php">Home</a></li>
            <li class="active"><a href="aboutus.php">About</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
          </ul>

<?php
if(isset($_SESSION['login_user1'])){

?>


          <ul class="nav navbar-nav navbar-right">
            <li><a href="#"><span class="glyphicon glyphicon-user"></span> Welcome <?php echo $_SESSION['login_user1']; ?> </a></li>
            <li><a href="myrestaurant.php">MANAGER CONTROL PANEL</a></li>
            <li><a href="logout_m.php"><span class="glyphicon glyphicon-log-out"></span> Log Out </a></li>
          </ul>
<?php
}
else if (isset($_SESSION['login_user2'])) {
  ?>
           <ul class="nav navbar-nav navbar-right">
            <li><a href="#"><span class="glyphicon glyphicon-user"></span> Welcome <?php echo $_SESSION['login_user2']; ?> </a></li>
            <li><a href="foodlist.php"><span class="glyphicon glyphicon-cutlery"></span> Food Zone </a></li>
            <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart 
            (<?php
              if(isset($_SESSION["cart"])){
              $count = count($_SESSION["cart"]); 
              echo "$count"; 
            }
              else
                echo "0";
              ?>)
            </a></li>
            <li><a href="logout_u.php"><span class="glyphicon glyphicon-log-out"></span> Log Out </a></li>
          </ul>
  <?php        
}
else {

  ?>

<ul class="nav navbar-nav navbar-right">
            <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-user"></span> Sign Up <span class="caret"></span> </a>
                <ul class="dropdown-menu">
              <li> <a href="customersignup.php"> User Sign-up</a></li>
              <li> <a href="managersignup.php"> Manager Sign-up</a></li>
          
            </ul>
            </li>

            <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-log-in"></span> Login <span class="caret"></span></a>
              <ul class="dropdown-menu">
              <li> <a href="customerlogin.php"> User Login</a></li>
              <li> <a href="managerlogin.php"> Manager Login</a></li>

            </ul>
            </li>
          </ul>

<?php
}
?>
        </div>

      </div>
    </nav>

    <div class="wide">
        
        <div class="tagline">It's our <font color="red"><strong>Passion </strong></font> to serve you  <font color="green"><strong><em>best Food </em> !</strong></font></div>
    </div>

    <div class="paragraph1">
      <h1>Brief Intro</h1>
      <h3><p>Toast & Tonic was founded in early 2000. Our Chefs have been working wih us more than 19 years and our reeipsi is also been same as when we started. thats what customer like about us.</p></h3>
    </div>

    <div class="col-xs-12 line"><hr></div>

    <div class="col-md-10" style="float: none; margin: 0 auto;">
        <div class="paragraph2">
          <h1><center>A FEW THINGS WE ADD TO OUR SERVICE</center></h1>
          <p><br>
          <div class="goldcolor">
          <h2>1. Value customer </h2>
          </div>
          <h3> We care for you and your order , so we have as muchas food on our web.</h3> 
          </p>
          <p><br>
          <div class="goldcolor">
          <h2>2. Better Data Integrate </h2>
          </div>
          <h3>As your order is valuable we make it easier for admin side to view your order and update. </h3> 
          </p>
          <p><br>
          <div class="goldcolor">
            <h2>3. Free Delivery </h2>
            </div>
            <h3> Like us other food ordering website we dont charge you a penny for food delivery. </h3>
          </p>
          <p><br>
          <div class="goldcolor">
            <h2>4. Gift Cards</h2>
            </div>
            <h3>we care for our valuable customers special days. for that we give them a birthday card vouchers which allows up to 40 % discounts on order.</h3>
          </p>
          <p><br>
          <div class="goldcolor">
            <h2>5. Fast Delivery</h2>
            </div>
            <h3>Our courier guys get best vehicle to delivery your order in a fast manner in order to prevent it from cold.</h3>
          </p>
        </div>
    </div>

  <div class="paragraph3">
    <div class="missionbox">
      <div class="missionfont">
      <strong>Our mission is to ensure nobody has a bad meal.</strong>
      
    </div>
     
    </div>
    
  </div>   
  
<p> 

</p>  

  <footer class="container-fluid bg-4 text-center">
  <br>
  <p> ToastTonic 2020 | © All Rights Reserved by Vrajesh Choksi @ Spectrum Solutions.</p>
  <br>
  </footer>
</html>